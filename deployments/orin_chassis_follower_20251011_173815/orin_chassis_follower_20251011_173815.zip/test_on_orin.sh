#!/bin/bash
# Test script for chassis path follower
set -e

cd "$(dirname "$0")/ros2"

# Source workspace
if [ -f "install/setup.bash" ]; then
    source install/setup.bash
else
    echo "ERROR: Workspace not built! Run ./build_on_orin.sh first"
    exit 1
fi

echo "==========================================="
echo "  Testing Chassis Path Follower"
echo "==========================================="
echo ""

# Test 1: Check if node is available
echo "[Test 1] Checking node availability..."
if ros2 pkg list | grep -q gik9dof_controllers; then
    echo "  ✅ gik9dof_controllers package found"
else
    echo "  ❌ gik9dof_controllers package not found"
    exit 1
fi

# Test 2: Launch in background
echo ""
echo "[Test 2] Launching node (Mode 2 - Pure Pursuit)..."
echo "  Press Ctrl+C to stop"
echo ""

ros2 launch gik9dof_controllers chassis_path_follower_launch.py controller_mode:=2