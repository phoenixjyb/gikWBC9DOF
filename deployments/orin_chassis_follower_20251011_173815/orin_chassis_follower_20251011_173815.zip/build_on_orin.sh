#!/bin/bash
# Build script for Orin
set -e

echo "==========================================="
echo "  Building ROS2 Workspace on Orin"
echo "==========================================="
echo ""

cd "$(dirname "$0")/ros2"

# Source ROS2 Humble
if [ -f "/opt/ros/humble/setup.bash" ]; then
    echo "[1/3] Sourcing ROS2 Humble..."
    source /opt/ros/humble/setup.bash
else
    echo "ERROR: ROS2 Humble not found!"
    exit 1
fi

# Clean previous build
echo "[2/3] Cleaning previous build..."
rm -rf build/ install/ log/

# Build workspace
echo "[3/3] Building workspace..."
colcon build --cmake-args -DCMAKE_BUILD_TYPE=Release

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Build successful!"
    echo ""
    echo "To use the workspace:"
    echo "  source install/setup.bash"
    echo ""
    echo "To launch chassis path follower:"
    echo "  ros2 launch gik9dof_controllers chassis_path_follower_launch.py"
else
    echo ""
    echo "❌ Build failed!"
    exit 1
fi