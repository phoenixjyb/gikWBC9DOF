//
// File: chassisPathFollowerCodegen_data.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 11-Oct-2025 00:19:03
//

#ifndef CHASSISPATHFOLLOWERCODEGEN_DATA_H
#define CHASSISPATHFOLLOWERCODEGEN_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for chassisPathFollowerCodegen_data.h
//
// [EOF]
//
