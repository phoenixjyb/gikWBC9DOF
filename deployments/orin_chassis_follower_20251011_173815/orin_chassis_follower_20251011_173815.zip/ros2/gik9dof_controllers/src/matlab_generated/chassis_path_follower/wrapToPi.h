//
// File: wrapToPi.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 11-Oct-2025 00:19:03
//

#ifndef WRAPTOPI_H
#define WRAPTOPI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
void wrapToPi(double &lambda);

void wrapToPi(double lambda_data[]);

} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for wrapToPi.h
//
// [EOF]
//
