//
// File: minOrMax.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 11-Oct-2025 00:19:03
//

#ifndef MINORMAX_H
#define MINORMAX_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
double maximum(const double x[3]);

double minimum(const double x_data[], int x_size, int &idx);

} // namespace internal
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for minOrMax.h
//
// [EOF]
//
