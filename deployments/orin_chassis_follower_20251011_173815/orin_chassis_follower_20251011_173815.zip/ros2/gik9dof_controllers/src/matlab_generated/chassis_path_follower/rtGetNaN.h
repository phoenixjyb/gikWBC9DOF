//
// File: rtGetNaN.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 11-Oct-2025 00:19:03
//

#ifndef RTGETNAN_H
#define RTGETNAN_H

// Include Files
#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#ifdef __cplusplus
}
#endif
#endif
//
// File trailer for rtGetNaN.h
//
// [EOF]
//
