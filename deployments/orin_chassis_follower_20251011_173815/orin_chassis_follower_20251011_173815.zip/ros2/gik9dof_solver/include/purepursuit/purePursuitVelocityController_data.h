//
// File: purePursuitVelocityController_data.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 12:15:43
//

#ifndef PUREPURSUITVELOCITYCONTROLLER_DATA_H
#define PUREPURSUITVELOCITYCONTROLLER_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for purePursuitVelocityController_data.h
//
// [EOF]
//
