//
// File: purePursuitVelocityController_terminate.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 12:15:43
//

#ifndef PUREPURSUITVELOCITYCONTROLLER_TERMINATE_H
#define PUREPURSUITVELOCITYCONTROLLER_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof_purepursuit {
extern void purePursuitVelocityController_terminate();

}

#endif
//
// File trailer for purePursuitVelocityController_terminate.h
//
// [EOF]
//
