//
// File: purePursuitVelocityController_initialize.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 12:15:43
//

#ifndef PUREPURSUITVELOCITYCONTROLLER_INITIALIZE_H
#define PUREPURSUITVELOCITYCONTROLLER_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof_purepursuit {
extern void purePursuitVelocityController_initialize();

}

#endif
//
// File trailer for purePursuitVelocityController_initialize.h
//
// [EOF]
//
