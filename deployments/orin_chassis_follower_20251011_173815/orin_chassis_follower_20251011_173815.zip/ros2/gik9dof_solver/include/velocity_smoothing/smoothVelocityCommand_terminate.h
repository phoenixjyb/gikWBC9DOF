//
// File: smoothVelocityCommand_terminate.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 10-Oct-2025 00:47:40
//

#ifndef SMOOTHVELOCITYCOMMAND_TERMINATE_H
#define SMOOTHVELOCITYCOMMAND_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void smoothVelocityCommand_terminate();

#endif
//
// File trailer for smoothVelocityCommand_terminate.h
//
// [EOF]
//
