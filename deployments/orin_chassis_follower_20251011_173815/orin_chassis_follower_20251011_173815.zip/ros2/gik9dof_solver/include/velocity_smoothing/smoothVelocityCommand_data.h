//
// File: smoothVelocityCommand_data.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 10-Oct-2025 00:47:40
//

#ifndef SMOOTHVELOCITYCOMMAND_DATA_H
#define SMOOTHVELOCITYCOMMAND_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for smoothVelocityCommand_data.h
//
// [EOF]
//
