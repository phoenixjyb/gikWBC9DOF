//
// File: holisticVelocityController_terminate.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 11:20:37
//

#ifndef HOLISTICVELOCITYCONTROLLER_TERMINATE_H
#define HOLISTICVELOCITYCONTROLLER_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof_velocity {
extern void holisticVelocityController_terminate();

}

#endif
//
// File trailer for holisticVelocityController_terminate.h
//
// [EOF]
//
