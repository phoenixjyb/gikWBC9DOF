//
// File: holisticVelocityController_initialize.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 11:20:37
//

#ifndef HOLISTICVELOCITYCONTROLLER_INITIALIZE_H
#define HOLISTICVELOCITYCONTROLLER_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof_velocity {
extern void holisticVelocityController_initialize();

}

#endif
//
// File trailer for holisticVelocityController_initialize.h
//
// [EOF]
//
