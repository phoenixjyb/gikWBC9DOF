//
// File: smoothVelocityCommand_terminate.cpp
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 10-Oct-2025 00:47:40
//

// Include Files
#include "smoothVelocityCommand_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void smoothVelocityCommand_terminate()
{
}

//
// File trailer for smoothVelocityCommand_terminate.cpp
//
// [EOF]
//
