//
// File: smoothVelocityCommand_initialize.cpp
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 10-Oct-2025 00:47:40
//

// Include Files
#include "smoothVelocityCommand_initialize.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void smoothVelocityCommand_initialize()
{
}

//
// File trailer for smoothVelocityCommand_initialize.cpp
//
// [EOF]
//
