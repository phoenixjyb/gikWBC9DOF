//
// File: purePursuitVelocityController_initialize.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 12:15:43
//

// Include Files
#include "purePursuitVelocityController_initialize.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace gik9dof_purepursuit {
void purePursuitVelocityController_initialize()
{
}

} // namespace gik9dof_purepursuit

//
// File trailer for purePursuitVelocityController_initialize.cpp
//
// [EOF]
//
