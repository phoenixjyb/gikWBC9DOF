//
// File: holisticVelocityController_initialize.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 11:20:37
//

// Include Files
#include "holisticVelocityController_initialize.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace gik9dof_velocity {
void holisticVelocityController_initialize()
{
}

} // namespace gik9dof_velocity

//
// File trailer for holisticVelocityController_initialize.cpp
//
// [EOF]
//
