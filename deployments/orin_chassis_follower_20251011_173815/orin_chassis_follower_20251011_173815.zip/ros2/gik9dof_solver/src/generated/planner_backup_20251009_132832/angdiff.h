//
// File: angdiff.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 19:31:57
//

#ifndef ANGDIFF_H
#define ANGDIFF_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
double angdiff(double x, double y);

}
} // namespace gik9dof

#endif
//
// File trailer for angdiff.h
//
// [EOF]
//
