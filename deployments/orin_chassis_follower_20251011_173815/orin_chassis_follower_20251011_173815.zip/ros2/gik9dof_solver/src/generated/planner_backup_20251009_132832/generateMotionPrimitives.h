//
// File: generateMotionPrimitives.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 19:31:57
//

#ifndef GENERATEMOTIONPRIMITIVES_H
#define GENERATEMOTIONPRIMITIVES_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
struct struct_T;

}

// Function Declarations
namespace gik9dof {
void generateMotionPrimitives(struct_T primitives[30]);

}

#endif
//
// File trailer for generateMotionPrimitives.h
//
// [EOF]
//
