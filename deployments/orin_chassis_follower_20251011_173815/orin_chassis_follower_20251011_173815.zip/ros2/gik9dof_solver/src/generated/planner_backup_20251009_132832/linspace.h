//
// File: linspace.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 19:31:57
//

#ifndef LINSPACE_H
#define LINSPACE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
void linspace(double d2, double n, double y_data[], int y_size[2]);

}
} // namespace gik9dof

#endif
//
// File trailer for linspace.h
//
// [EOF]
//
