//
// File: atan2.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 19:31:57
//

#ifndef ATAN2_H
#define ATAN2_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
double b_atan2(double y, double x);

}
} // namespace gik9dof

#endif
//
// File trailer for atan2.h
//
// [EOF]
//
