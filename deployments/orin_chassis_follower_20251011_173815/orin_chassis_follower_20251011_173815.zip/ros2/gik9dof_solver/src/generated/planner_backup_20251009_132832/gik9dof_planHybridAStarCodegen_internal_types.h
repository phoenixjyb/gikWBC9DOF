//
// File: gik9dof_planHybridAStarCodegen_internal_types.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 19:31:57
//

#ifndef GIK9DOF_PLANHYBRIDASTARCODEGEN_INTERNAL_TYPES_H
#define GIK9DOF_PLANHYBRIDASTARCODEGEN_INTERNAL_TYPES_H

// Include Files
#include "gik9dof_planHybridAStarCodegen_types.h"
#include "rtwtypes.h"

// Type Definitions
namespace gik9dof {
struct struct_T {
  double Vx;
  double Wz;
  double dt;
  double arc_length;
};

} // namespace gik9dof

#endif
//
// File trailer for gik9dof_planHybridAStarCodegen_internal_types.h
//
// [EOF]
//
