//
// File: CoderTimeAPI.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 09-Oct-2025 13:46:29
//

#ifndef CODERTIMEAPI_H
#define CODERTIMEAPI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
class HybridAStarPlanner;

}

// Type Definitions
namespace gik9dof {
class CoderTimeAPI {
public:
  static void callCoderClockGettime_init(HybridAStarPlanner *aInstancePtr);
};

} // namespace gik9dof

#endif
//
// File trailer for CoderTimeAPI.h
//
// [EOF]
//
