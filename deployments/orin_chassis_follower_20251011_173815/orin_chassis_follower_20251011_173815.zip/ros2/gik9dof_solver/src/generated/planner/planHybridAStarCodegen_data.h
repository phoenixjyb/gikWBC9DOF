//
// File: planHybridAStarCodegen_data.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 09-Oct-2025 13:46:29
//

#ifndef PLANHYBRIDASTARCODEGEN_DATA_H
#define PLANHYBRIDASTARCODEGEN_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for planHybridAStarCodegen_data.h
//
// [EOF]
//
