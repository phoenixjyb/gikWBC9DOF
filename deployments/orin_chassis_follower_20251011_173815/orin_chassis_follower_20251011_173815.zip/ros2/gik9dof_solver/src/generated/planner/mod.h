//
// File: mod.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 09-Oct-2025 13:46:29
//

#ifndef MOD_H
#define MOD_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
double b_mod(double x);

}
} // namespace gik9dof

#endif
//
// File trailer for mod.h
//
// [EOF]
//
