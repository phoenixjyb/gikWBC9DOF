//
// File: angdiff.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 09-Oct-2025 13:46:29
//

#ifndef ANGDIFF_H
#define ANGDIFF_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
double angdiff(double x, double y);

}
} // namespace gik9dof

#endif
//
// File trailer for angdiff.h
//
// [EOF]
//
