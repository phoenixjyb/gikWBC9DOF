//
// File: planHybridAStarCodegen_internal_types.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 09-Oct-2025 13:46:29
//

#ifndef PLANHYBRIDASTARCODEGEN_INTERNAL_TYPES_H
#define PLANHYBRIDASTARCODEGEN_INTERNAL_TYPES_H

// Include Files
#include "planHybridAStarCodegen_types.h"
#include "rtwtypes.h"

// Type Definitions
namespace gik9dof {
struct struct_T {
  double Vx;
  double Wz;
  double dt;
  double arc_length;
};

} // namespace gik9dof

#endif
//
// File trailer for planHybridAStarCodegen_internal_types.h
//
// [EOF]
//
