//
// File: generateMotionPrimitives.h
//
// MATLAB Coder version            : 24.1
// C/C++ source code generated on  : 09-Oct-2025 13:46:29
//

#ifndef GENERATEMOTIONPRIMITIVES_H
#define GENERATEMOTIONPRIMITIVES_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
struct struct_T;

}

// Function Declarations
namespace gik9dof {
void generateMotionPrimitives(struct_T primitives[30]);

}

#endif
//
// File trailer for generateMotionPrimitives.h
//
// [EOF]
//
