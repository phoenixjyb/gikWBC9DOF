//
// File: norm.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef NORM_H
#define NORM_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double b_norm(const array<double, 1U> &x);

}

#endif
//
// File trailer for norm.h
//
// [EOF]
//
