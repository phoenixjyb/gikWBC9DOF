//
// File: gik9dof_codegen_inuse_solveGIKStepWrapper_terminate.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef GIK9DOF_CODEGEN_INUSE_SOLVEGIKSTEPWRAPPER_TERMINATE_H
#define GIK9DOF_CODEGEN_INUSE_SOLVEGIKSTEPWRAPPER_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void gik9dof_codegen_inuse_solveGIKStepWrapper_terminate();

#endif
//
// File trailer for gik9dof_codegen_inuse_solveGIKStepWrapper_terminate.h
//
// [EOF]
//
