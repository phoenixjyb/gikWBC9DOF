//
// File: eml_rand_mt19937ar_stateful.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef EML_RAND_MT19937AR_STATEFUL_H
#define EML_RAND_MT19937AR_STATEFUL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void eml_rand_mt19937ar_stateful_init();

#endif
//
// File trailer for eml_rand_mt19937ar_stateful.h
//
// [EOF]
//
