//
// File: eml_rand_mt19937ar_stateful.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

// Include Files
#include "eml_rand_mt19937ar_stateful.h"
#include "eml_rand_mt19937ar.h"
#include "gik9dof_codegen_inuse_solveGIKStepWrapper_data.h"
#include "rt_nonfinite.h"
#include <cstring>

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void eml_rand_mt19937ar_stateful_init()
{
  coder::internal::randfun::eml_rand_mt19937ar(state);
}

//
// File trailer for eml_rand_mt19937ar_stateful.cpp
//
// [EOF]
//
