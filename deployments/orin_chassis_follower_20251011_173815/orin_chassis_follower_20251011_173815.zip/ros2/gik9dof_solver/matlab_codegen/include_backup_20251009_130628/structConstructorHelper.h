//
// File: structConstructorHelper.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef STRUCTCONSTRUCTORHELPER_H
#define STRUCTCONSTRUCTORHELPER_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct struct1_T;

// Function Declarations
void binary_expand_op_10(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_11(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_12(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_13(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_14(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_15(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_16(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_17(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_18(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_19(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_20(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_21(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_22(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_23(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_24(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_25(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_26(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_27(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         const coder::array<double, 1U> &in5);

void binary_expand_op_28(struct1_T in1[22], const coder::array<double, 1U> &in3,
                         int in4, const coder::array<double, 1U> &in5,
                         const coder::array<double, 1U> &in7);

void binary_expand_op_8(struct1_T in1[22], const coder::array<double, 1U> &in3,
                        const coder::array<double, 1U> &in5);

void binary_expand_op_9(struct1_T in1[22], const coder::array<double, 1U> &in3,
                        const coder::array<double, 1U> &in5);

#endif
//
// File trailer for structConstructorHelper.h
//
// [EOF]
//
