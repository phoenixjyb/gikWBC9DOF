//
// File: mldivide.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef MLDIVIDE_H
#define MLDIVIDE_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void mldivide(const array<double, 2U> &A, array<double, 1U> &B);

}

#endif
//
// File trailer for mldivide.h
//
// [EOF]
//
