//
// File: CoderTimeAPI.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

// Include Files
#include "CoderTimeAPI.h"
#include "gik9dof_codegen_inuse_solveGIKStepWrapper_data.h"
#include "rt_nonfinite.h"
#include <cstring>

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void CoderTimeAPI::callCoderClockGettime_init()
{
  freq_not_empty = false;
}

//
// File trailer for CoderTimeAPI.cpp
//
// [EOF]
//
