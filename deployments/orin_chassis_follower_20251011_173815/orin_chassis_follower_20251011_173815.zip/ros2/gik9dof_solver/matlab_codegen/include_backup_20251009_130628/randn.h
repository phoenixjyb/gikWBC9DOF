//
// File: randn.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef RANDN_H
#define RANDN_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void b_randn(double r[3]);

int randn(const double varargin_1[2], double r_data[]);

void randn(double r[4]);

} // namespace coder

#endif
//
// File trailer for randn.h
//
// [EOF]
//
