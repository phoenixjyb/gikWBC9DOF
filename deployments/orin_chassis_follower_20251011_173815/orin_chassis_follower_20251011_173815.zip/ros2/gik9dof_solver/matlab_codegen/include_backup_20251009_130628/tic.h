//
// File: tic.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef TIC_H
#define TIC_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double tic(double &tstart_tv_nsec);

}

#endif
//
// File trailer for tic.h
//
// [EOF]
//
