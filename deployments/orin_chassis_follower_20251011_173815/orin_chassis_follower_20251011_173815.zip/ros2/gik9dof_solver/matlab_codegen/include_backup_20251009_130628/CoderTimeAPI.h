//
// File: CoderTimeAPI.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef CODERTIMEAPI_H
#define CODERTIMEAPI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
class CoderTimeAPI {
public:
  static void callCoderClockGettime_init();
};

#endif
//
// File trailer for CoderTimeAPI.h
//
// [EOF]
//
