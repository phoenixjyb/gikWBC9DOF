//
// File: xrotg.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef XROTG_H
#define XROTG_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace blas {
double xrotg(double &a, double &b, double &s);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xrotg.h
//
// [EOF]
//
