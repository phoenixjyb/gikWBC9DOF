//
// File: toc.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef TOC_H
#define TOC_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double toc(double tstart_tv_sec, double tstart_tv_nsec);

}

#endif
//
// File trailer for toc.h
//
// [EOF]
//
