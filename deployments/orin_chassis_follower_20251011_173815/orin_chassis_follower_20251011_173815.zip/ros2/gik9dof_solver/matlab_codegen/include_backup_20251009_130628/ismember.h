//
// File: ismember.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef ISMEMBER_H
#define ISMEMBER_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void isMember(const array<double, 1U> &a, const double s[22],
              array<boolean_T, 1U> &tf, array<int, 1U> &loc);

}

#endif
//
// File trailer for ismember.h
//
// [EOF]
//
