//
// File: validatestring.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef VALIDATESTRING_H
#define VALIDATESTRING_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void validatestring(const char str_data[], const int str_size[2],
                    char out_data[], int out_size[2]);

}

#endif
//
// File trailer for validatestring.h
//
// [EOF]
//
