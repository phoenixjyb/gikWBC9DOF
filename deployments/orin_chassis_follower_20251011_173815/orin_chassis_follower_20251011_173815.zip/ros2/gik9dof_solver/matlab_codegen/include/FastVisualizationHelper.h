//
// File: FastVisualizationHelper.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

#ifndef FASTVISUALIZATIONHELPER_H
#define FASTVISUALIZATIONHELPER_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace gik9dof {
namespace coder {
namespace robotics {
namespace manip {
namespace internal {
class FastVisualizationHelper {
public:
  FastVisualizationHelper();
  ~FastVisualizationHelper();
};

} // namespace internal
} // namespace manip
} // namespace robotics
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for FastVisualizationHelper.h
//
// [EOF]
//
