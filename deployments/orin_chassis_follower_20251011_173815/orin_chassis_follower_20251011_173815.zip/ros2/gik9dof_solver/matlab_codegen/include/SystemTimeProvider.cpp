//
// File: SystemTimeProvider.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

// Include Files
#include "SystemTimeProvider.h"
#include "rt_nonfinite.h"
#include <cstring>

// Function Definitions
//
// Arguments    : void
// Return Type  : SystemTimeProvider
//
namespace gik9dof {
namespace coder {
namespace robotics {
namespace core {
namespace internal {
SystemTimeProvider::SystemTimeProvider() = default;

//
// Arguments    : void
// Return Type  : void
//
SystemTimeProvider::~SystemTimeProvider() = default;

} // namespace internal
} // namespace core
} // namespace robotics
} // namespace coder
} // namespace gik9dof

//
// File trailer for SystemTimeProvider.cpp
//
// [EOF]
//
