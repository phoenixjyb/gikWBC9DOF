//
// File: diff.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 08-Oct-2025 12:14:03
//

#ifndef DIFF_H
#define DIFF_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void diff(const array<double, 2U> &x, array<double, 1U> &y);

}

#endif
//
// File trailer for diff.h
//
// [EOF]
//
