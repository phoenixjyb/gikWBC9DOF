//
// File: find.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

#ifndef FIND_H
#define FIND_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
int eml_find(const bool x[9], int i_data[]);

}
} // namespace gik9dof

#endif
//
// File trailer for find.h
//
// [EOF]
//
