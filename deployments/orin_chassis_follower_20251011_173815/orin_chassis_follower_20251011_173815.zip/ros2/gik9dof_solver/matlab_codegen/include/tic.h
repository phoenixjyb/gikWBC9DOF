//
// File: tic.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

#ifndef TIC_H
#define TIC_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
class GIKSolver;

}

// Function Declarations
namespace gik9dof {
namespace coder {
double tic(GIKSolver *aInstancePtr, double &tstart_tv_nsec);

}
} // namespace gik9dof

#endif
//
// File trailer for tic.h
//
// [EOF]
//
