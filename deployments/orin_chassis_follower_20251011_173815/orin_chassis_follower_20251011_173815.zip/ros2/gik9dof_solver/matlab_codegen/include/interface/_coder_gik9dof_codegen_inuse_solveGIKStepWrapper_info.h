//
// File: _coder_gik9dof_codegen_inuse_solveGIKStepWrapper_info.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

#ifndef _CODER_GIK9DOF_CODEGEN_INUSE_SOLVEGIKSTEPWRAPPER_INFO_H
#define _CODER_GIK9DOF_CODEGEN_INUSE_SOLVEGIKSTEPWRAPPER_INFO_H

// Include Files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
//
// File trailer for _coder_gik9dof_codegen_inuse_solveGIKStepWrapper_info.h
//
// [EOF]
//
