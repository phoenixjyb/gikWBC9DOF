//
// File: eye.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

#ifndef EYE_H
#define EYE_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
void eye(double varargin_1, ::coder::array<double, 2U> &b_I);

}
} // namespace gik9dof

#endif
//
// File trailer for eye.h
//
// [EOF]
//
