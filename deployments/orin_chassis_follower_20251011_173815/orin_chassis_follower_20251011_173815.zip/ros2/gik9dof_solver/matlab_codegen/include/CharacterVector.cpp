//
// File: CharacterVector.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

// Include Files
#include "CharacterVector.h"
#include "rt_nonfinite.h"
#include <cstring>

// Function Definitions
//
// Arguments    : void
// Return Type  : CharacterVector
//
namespace gik9dof {
namespace coder {
namespace robotics {
namespace manip {
namespace internal {
CharacterVector::CharacterVector() = default;

//
// Arguments    : void
// Return Type  : void
//
CharacterVector::~CharacterVector() = default;

} // namespace internal
} // namespace manip
} // namespace robotics
} // namespace coder
} // namespace gik9dof

//
// File trailer for CharacterVector.cpp
//
// [EOF]
//
