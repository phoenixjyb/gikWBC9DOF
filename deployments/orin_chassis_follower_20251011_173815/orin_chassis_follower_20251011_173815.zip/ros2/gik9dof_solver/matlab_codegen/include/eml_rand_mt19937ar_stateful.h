//
// File: eml_rand_mt19937ar_stateful.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 09-Oct-2025 12:02:50
//

#ifndef EML_RAND_MT19937AR_STATEFUL_H
#define EML_RAND_MT19937AR_STATEFUL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
class GIKSolver;

}

// Function Declarations
namespace gik9dof {
void eml_rand_mt19937ar_stateful_init(GIKSolver *aInstancePtr);

}

#endif
//
// File trailer for eml_rand_mt19937ar_stateful.h
//
// [EOF]
//
