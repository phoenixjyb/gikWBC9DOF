# Chassis Path Follower - Orin Deployment Package

**Created**: 20251011_173815  
**Target**: NVIDIA AGX Orin (ARM64)  
**ROS2**: Humble Hawksbill

## Package Contents

\\\
ros2/                          # ROS2 workspace
  ├── gik9dof_msgs/           # Custom message definitions
  ├── gik9dof_controllers/     # Chassis path follower node
  │   └── src/
  │       ├── chassis_path_follower_node.cpp
  │       └── matlab_generated/
  │           └── chassis_path_follower/  # MATLAB Coder generated files (ARM64)
  └── gik9dof_solver/          # GIK 9DOF solver
build_on_orin.sh              # Build script
test_on_orin.sh               # Test script
\\\

**Note**: MATLAB Coder generated files are included in os2/gik9dof_controllers/src/matlab_generated/

## Deployment Steps

### 1. Extract Package
\\\ash
cd ~
unzip orin_chassis_follower_20251011_173815.zip
cd orin_chassis_follower_20251011_173815
\\\

### 2. Build on Orin
\\\ash
chmod +x build_on_orin.sh
./build_on_orin.sh
\\\

**Expected build time**: ~5 minutes  
**Expected output**: All 3 packages build successfully

### 3. Test the Node
\\\ash
chmod +x test_on_orin.sh
./test_on_orin.sh
\\\

### 4. Manual Launch (Alternative)
\\\ash
cd ros2
source install/setup.bash

# Mode 0: Differentiation controller
ros2 launch gik9dof_controllers chassis_path_follower_launch.py controller_mode:=0

# Mode 1: Heading controller
ros2 launch gik9dof_controllers chassis_path_follower_launch.py controller_mode:=1

# Mode 2: Pure pursuit (default)
ros2 launch gik9dof_controllers chassis_path_follower_launch.py controller_mode:=2
\\\

## Testing the Controller

### Publish a Test Path
\\\ash
# Terminal 1: Launch controller
ros2 launch gik9dof_controllers chassis_path_follower_launch.py

# Terminal 2: Publish test path (straight line)
ros2 topic pub /path nav_msgs/msg/Path '{
  header: {frame_id: "map"},
  poses: [
    {pose: {position: {x: 0.0, y: 0.0, z: 0.0}, orientation: {w: 1.0}}},
    {pose: {position: {x: 1.0, y: 0.0, z: 0.0}, orientation: {w: 1.0}}},
    {pose: {position: {x: 2.0, y: 0.0, z: 0.0}, orientation: {w: 1.0}}},
    {pose: {position: {x: 3.0, y: 0.0, z: 0.0}, orientation: {w: 1.0}}}
  ]
}' -1

# Terminal 3: Monitor velocity commands
ros2 topic echo /cmd_vel
\\\

### Monitor Status
\\\ash
# Path following status
ros2 topic echo /path_following_active

# Node info
ros2 node info /chassis_path_follower
\\\

## Controller Modes

| Mode | Name | Description |
|------|------|-------------|
| 0 | Differentiation | Curvature-based control with differentiation |
| 1 | Heading | Heading controller with lookahead |
| 2 | Pure Pursuit | Pure pursuit with adaptive lookahead (default) |

## Parameters

Key parameters (can be set in launch file):
- \controller_mode\: 0, 1, or 2
- \x_max\: Maximum linear velocity (default: 1.0 m/s)
- \wz_max\: Maximum angular velocity (default: 1.0 rad/s)
- \lookahead_base\: Base lookahead distance (default: 0.3 m)
- \lookahead_gain\: Velocity-dependent lookahead gain (default: 0.5)
- \goal_tolerance\: Distance threshold for goal reached (default: 0.1 m)

See \os2/gik9dof_controllers/launch/chassis_path_follower_launch.py\ for all parameters.

## Topics

**Subscribed**:
- \/path\ (nav_msgs/msg/Path): Path to follow
- \/odom\ (nav_msgs/msg/Odometry): Current robot pose

**Published**:
- \/cmd_vel\ (geometry_msgs/msg/Twist): Velocity commands
- \/path_following_active\ (std_msgs/msg/Bool): Following status

## Troubleshooting

### Build fails
\\\ash
# Clean and rebuild
cd ros2
rm -rf build/ install/ log/
source /opt/ros/humble/setup.bash
colcon build
\\\

### Node doesn't start
\\\ash
# Check if package is installed
ros2 pkg list | grep gik9dof

# Check ROS2 environment
env | grep ROS
\\\

### No velocity output
- Check if path was published: \os2 topic echo /path\
- Check if odometry is available: \os2 topic echo /odom\
- Check node logs: \os2 node info /chassis_path_follower\

## Files Modified from Base

This deployment includes fixes for:
1. ✅ Python dependencies (empy 3.3.4)
2. ✅ C++ type mismatches (struct0_T, struct1_T, struct3_T)
3. ✅ Bounded array usage (PathInfo arrays)
4. ✅ Function call signature corrections
5. ✅ Parameter structure alignment

See \WSL_BUILD_SUCCESS.md\ in the main repository for detailed change log.

## Support

For issues, refer to:
- Main repository: phoenixjyb/gikWBC9DOF
- Branch: codegencc45-main
- Session docs: \WSL_BUILD_SUCCESS.md\

---

**Package created**: 20251011_173815  
**Validated in**: WSL Ubuntu 22.04 + ROS2 Humble  
**Target platform**: NVIDIA AGX Orin (ARM64)
