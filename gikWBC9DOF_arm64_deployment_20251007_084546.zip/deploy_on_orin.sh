#!/bin/bash
# Deployment script for AGX Orin
# Auto-generated on 2025-10-07 08:45:03

echo "========================================="
echo "GIK 9-DOF Solver - Orin Deployment"
echo "========================================="
echo ""

# Setup workspace
echo "Setting up workspace..."
mkdir -p ~/gikWBC9DOF/codegen/arm64_realtime
mkdir -p ~/gikWBC9DOF/ros2

# Copy files
echo "Copying generated code..."
cp -r codegen/arm64_realtime/* ~/gikWBC9DOF/codegen/arm64_realtime/

echo "Copying ROS2 packages..."
cp -r ros2/* ~/gikWBC9DOF/ros2/

echo "Copying URDF..."
cp mobile_manipulator_PPR_base_corrected.urdf ~/gikWBC9DOF/

# Build ROS2 workspace
echo ""
echo "Building ROS2 workspace..."
cd ~/gikWBC9DOF/ros2
colcon build --packages-select gik9dof_msgs gik9dof_solver gik9dof_controllers

echo ""
echo "========================================="
echo "Deployment complete!"
echo "========================================="
echo ""
echo "To run the solver:"
echo "  source ~/gikWBC9DOF/ros2/install/setup.bash"
echo "  ros2 run gik9dof_solver gik9dof_solver_node --ros-args -p use_warm_start:=true"
echo ""
