//
// File: KinematicConstraint.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

#ifndef KINEMATICCONSTRAINT_H
#define KINEMATICCONSTRAINT_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
void minus(double in1[2], const double in2[2],
           const ::coder::array<double, 1U> &in3);

void minus(double in1[2], const ::coder::array<double, 1U> &in2);

} // namespace gik9dof

#endif
//
// File trailer for KinematicConstraint.h
//
// [EOF]
//
