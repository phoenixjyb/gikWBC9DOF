//
// File: ismember.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

#ifndef ISMEMBER_H
#define ISMEMBER_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
void isMember(const ::coder::array<double, 1U> &a, const double s[22],
              ::coder::array<bool, 1U> &tf, ::coder::array<int, 1U> &loc);

}
} // namespace gik9dof

#endif
//
// File trailer for ismember.h
//
// [EOF]
//
