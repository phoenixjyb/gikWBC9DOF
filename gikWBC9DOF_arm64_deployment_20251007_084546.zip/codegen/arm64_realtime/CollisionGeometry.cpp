//
// File: CollisionGeometry.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

// Include Files
#include "CollisionGeometry.h"
#include "rt_nonfinite.h"
#include <cstring>

// Function Definitions
//
// Arguments    : void
// Return Type  : CollisionGeometry
//
namespace gik9dof {
namespace coder {
namespace robotics {
namespace manip {
namespace internal {
CollisionGeometry::CollisionGeometry() = default;

//
// Arguments    : void
// Return Type  : void
//
CollisionGeometry::~CollisionGeometry() = default;

} // namespace internal
} // namespace manip
} // namespace robotics
} // namespace coder
} // namespace gik9dof

//
// File trailer for CollisionGeometry.cpp
//
// [EOF]
//
