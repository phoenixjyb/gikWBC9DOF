//
// File: xzlangeM.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

// Include Files
#include "xzlangeM.h"
#include "rt_nonfinite.h"
#include <cmath>
#include <cstring>

// Function Definitions
//
// Arguments    : const double x[9]
// Return Type  : double
//
namespace gik9dof {
namespace coder {
namespace internal {
namespace reflapack {
double xzlangeM(const double x[9])
{
  double y;
  int k;
  bool exitg1;
  y = 0.0;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 9)) {
    double absxk;
    absxk = std::abs(x[k]);
    if (std::isnan(absxk)) {
      y = rtNaN;
      exitg1 = true;
    } else {
      if (absxk > y) {
        y = absxk;
      }
      k++;
    }
  }
  return y;
}

} // namespace reflapack
} // namespace internal
} // namespace coder
} // namespace gik9dof

//
// File trailer for xzlangeM.cpp
//
// [EOF]
//
