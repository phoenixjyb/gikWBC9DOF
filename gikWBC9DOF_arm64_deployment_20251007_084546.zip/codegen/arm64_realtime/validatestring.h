//
// File: validatestring.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

#ifndef VALIDATESTRING_H
#define VALIDATESTRING_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
void validatestring(const char str_data[], const int str_size[2],
                    char out_data[], int out_size[2]);

}
} // namespace gik9dof

#endif
//
// File trailer for validatestring.h
//
// [EOF]
//
