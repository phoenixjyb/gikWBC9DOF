//
// File: FastVisualizationHelper.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

// Include Files
#include "FastVisualizationHelper.h"
#include "rt_nonfinite.h"
#include <cstring>

// Function Definitions
//
// Arguments    : void
// Return Type  : FastVisualizationHelper
//
namespace gik9dof {
namespace coder {
namespace robotics {
namespace manip {
namespace internal {
FastVisualizationHelper::FastVisualizationHelper() = default;

//
// Arguments    : void
// Return Type  : void
//
FastVisualizationHelper::~FastVisualizationHelper() = default;

} // namespace internal
} // namespace manip
} // namespace robotics
} // namespace coder
} // namespace gik9dof

//
// File trailer for FastVisualizationHelper.cpp
//
// [EOF]
//
