//
// File: svd.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

#ifndef SVD_H
#define SVD_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
void svd(const double A[9], double U[9], double s[3], double V[9]);

}
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for svd.h
//
// [EOF]
//
