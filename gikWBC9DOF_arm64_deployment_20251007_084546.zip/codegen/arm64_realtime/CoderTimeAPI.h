//
// File: CoderTimeAPI.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

#ifndef CODERTIMEAPI_H
#define CODERTIMEAPI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
class GIKSolver;

}

// Type Definitions
namespace gik9dof {
class CoderTimeAPI {
public:
  static void callCoderClockGettime_init(GIKSolver *aInstancePtr);
};

} // namespace gik9dof

#endif
//
// File trailer for CoderTimeAPI.h
//
// [EOF]
//
