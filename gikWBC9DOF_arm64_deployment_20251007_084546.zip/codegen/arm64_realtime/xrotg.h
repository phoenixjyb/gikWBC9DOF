//
// File: xrotg.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 07-Oct-2025 08:09:07
//

#ifndef XROTG_H
#define XROTG_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
namespace blas {
double xrotg(double &a, double &b, double &s);

}
} // namespace internal
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for xrotg.h
//
// [EOF]
//
