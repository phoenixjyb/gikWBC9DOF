//
// File: xzlascl.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef XZLASCL_H
#define XZLASCL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
namespace reflapack {
void b_xzlascl(double cfrom, double cto, double A[3]);

void xzlascl(double cfrom, double cto, double A[9]);

} // namespace reflapack
} // namespace internal
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for xzlascl.h
//
// [EOF]
//
