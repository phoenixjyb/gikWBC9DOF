//
// File: SystemTimeProvider.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

// Include Files
#include "SystemTimeProvider.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : SystemTimeProvider
//
namespace gik9dof {
namespace coder {
namespace robotics {
namespace core {
namespace internal {
SystemTimeProvider::SystemTimeProvider() = default;

//
// Arguments    : void
// Return Type  : void
//
SystemTimeProvider::~SystemTimeProvider() = default;

} // namespace internal
} // namespace core
} // namespace robotics
} // namespace coder
} // namespace gik9dof

//
// File trailer for SystemTimeProvider.cpp
//
// [EOF]
//
