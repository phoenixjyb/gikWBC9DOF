//
// File: xswap.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef XSWAP_H
#define XSWAP_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
namespace blas {
void xswap(double x[9], int ix0, int iy0);

}
} // namespace internal
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for xswap.h
//
// [EOF]
//
