//
// File: CoderTimeAPI.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef CODERTIMEAPI_H
#define CODERTIMEAPI_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
class GIKSolver;

}

// Type Definitions
namespace gik9dof {
class CoderTimeAPI {
public:
  static void callCoderClockGettime_init(GIKSolver *aInstancePtr);
};

} // namespace gik9dof

#endif
//
// File trailer for CoderTimeAPI.h
//
// [EOF]
//
