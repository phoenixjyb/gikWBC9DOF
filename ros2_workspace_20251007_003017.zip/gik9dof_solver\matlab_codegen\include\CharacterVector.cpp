//
// File: CharacterVector.cpp
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

// Include Files
#include "CharacterVector.h"
#include "rt_nonfinite.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : CharacterVector
//
namespace gik9dof {
namespace coder {
namespace robotics {
namespace manip {
namespace internal {
CharacterVector::CharacterVector() = default;

//
// Arguments    : void
// Return Type  : void
//
CharacterVector::~CharacterVector() = default;

} // namespace internal
} // namespace manip
} // namespace robotics
} // namespace coder
} // namespace gik9dof

//
// File trailer for CharacterVector.cpp
//
// [EOF]
//
