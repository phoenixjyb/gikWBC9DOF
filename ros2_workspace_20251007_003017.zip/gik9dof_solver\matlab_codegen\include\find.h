//
// File: find.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef FIND_H
#define FIND_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
int eml_find(const boolean_T x[9], int i_data[]);

}
} // namespace gik9dof

#endif
//
// File trailer for find.h
//
// [EOF]
//
