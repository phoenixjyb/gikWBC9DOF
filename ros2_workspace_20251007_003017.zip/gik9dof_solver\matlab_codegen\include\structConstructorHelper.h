//
// File: structConstructorHelper.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef STRUCTCONSTRUCTORHELPER_H
#define STRUCTCONSTRUCTORHELPER_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
struct struct1_T;

}

// Function Declarations
namespace gik9dof {
void binary_expand_op_8(struct1_T in1[3], const ::coder::array<double, 1U> &in3,
                        const ::coder::array<double, 1U> &in5);

void binary_expand_op_9(struct1_T in1[3], const ::coder::array<double, 1U> &in3,
                        int in5, const ::coder::array<double, 1U> &in6,
                        const ::coder::array<double, 1U> &in8);

} // namespace gik9dof

#endif
//
// File trailer for structConstructorHelper.h
//
// [EOF]
//
