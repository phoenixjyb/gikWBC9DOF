//
// File: validatestring.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef VALIDATESTRING_H
#define VALIDATESTRING_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
void validatestring(const char str_data[], const int str_size[2],
                    char out_data[], int out_size[2]);

}
} // namespace gik9dof

#endif
//
// File trailer for validatestring.h
//
// [EOF]
//
