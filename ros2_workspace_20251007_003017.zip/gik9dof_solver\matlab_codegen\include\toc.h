//
// File: toc.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef TOC_H
#define TOC_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
namespace gik9dof {
class GIKSolver;

}

// Function Declarations
namespace gik9dof {
namespace coder {
double toc(GIKSolver *aInstancePtr, double tstart_tv_sec,
           double tstart_tv_nsec);

}
} // namespace gik9dof

#endif
//
// File trailer for toc.h
//
// [EOF]
//
