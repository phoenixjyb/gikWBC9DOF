//
// mod.h
//
// Code generation for function 'mod'
//

#ifndef MOD_H
#define MOD_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double b_mod(double x);

}

#endif
// End of code generation (mod.h)
