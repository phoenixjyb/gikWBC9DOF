//
// gik9dof_codegen_stagedFollowTrajectory_initialize.h
//
// Code generation for function
// 'gik9dof_codegen_stagedFollowTrajectory_initialize'
//

#ifndef GIK9DOF_CODEGEN_STAGEDFOLLOWTRAJECTORY_INITIALIZE_H
#define GIK9DOF_CODEGEN_STAGEDFOLLOWTRAJECTORY_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void gik9dof_codegen_stagedFollowTrajectory_initialize();

#endif
// End of code generation (gik9dof_codegen_stagedFollowTrajectory_initialize.h)
