//
// File: sqrt.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef SQRT_H
#define SQRT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
namespace scalar {
void b_sqrt(creal_T &x);

}
} // namespace internal
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for sqrt.h
//
// [EOF]
//
