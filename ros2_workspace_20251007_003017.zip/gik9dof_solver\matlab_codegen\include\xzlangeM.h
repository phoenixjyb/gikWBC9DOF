//
// File: xzlangeM.h
//
// MATLAB Coder version            : 24.2
// C/C++ source code generated on  : 06-Oct-2025 17:03:24
//

#ifndef XZLANGEM_H
#define XZLANGEM_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace gik9dof {
namespace coder {
namespace internal {
namespace reflapack {
double xzlangeM(const double x[9]);

}
} // namespace internal
} // namespace coder
} // namespace gik9dof

#endif
//
// File trailer for xzlangeM.h
//
// [EOF]
//
